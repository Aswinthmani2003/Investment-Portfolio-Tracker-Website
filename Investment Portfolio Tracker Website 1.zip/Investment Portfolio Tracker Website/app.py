from flask import Flask, request, render_template, redirect, url_for, jsonify
from flask_pymongo import PyMongo
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from datetime import datetime
import os

app = Flask(__name__)

# ================= CONFIG =================
app.config['MONGO_URI'] = 'mongodb://127.0.0.1:27017/my-database'
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this to a random secret key

mongo = PyMongo(app)

# =========================================

# ================= MAIN ROUTES =================

@app.route('/')
def index():
    return redirect(url_for('home_page'))

# ================= HTML PAGE ROUTES =================

@app.route('/about.html')
def about_page():
    return render_template('about.html')

@app.route('/Dsp.html')
def dsp_page():
    return render_template('Dsp.html')

@app.route('/dspdetail.html')
def dspdetail_page():
    return render_template('dspdetail.html')

@app.route('/Dspsmallcap.html')
def dspsmallcap_page():
    return render_template('Dspsmallcap.html')

@app.route('/folio1.html')
def folio1_page():
    return render_template('folio1.html')

@app.route('/folio2.html')
def folio2_page():
    return render_template('folio2.html')

@app.route('/folio3.html')
def folio3_page():
    return render_template('folio3.html')

@app.route('/folio4.html')
def folio4_page():
    return render_template('folio4.html')

@app.route('/home.html')
def home_page():
    return render_template('home.html')

@app.route('/hsbc.html')
def hsbc_page():
    return render_template('hsbc.html')

@app.route('/invester.html')
def invester_page():
    return render_template('invester.html')

@app.route('/Investment.html')
def investment_page():
    return render_template('Investment.html')

@app.route('/login.html')
def login_page():
    return render_template('login.html')

@app.route('/mutualfundcalc.html')
def mutualfundcalc_page():
    return render_template('mutualfundcalc.html')

@app.route('/other.html')
def other_page():
    return render_template('other.html')

@app.route('/otherhsbc.html')
def otherhsbc_page():
    return render_template('otherhsbc.html')

@app.route('/otherpgim.html')
def otherpgim_page():
    return render_template('otherpgim.html')

@app.route('/othersSmallcap.html')
def otherssmallcap_page():
    return render_template('othersSmallcap.html')

@app.route('/pgim.html')
def pgim_page():
    return render_template('pgim.html')

@app.route('/pgimdebt.html')
def pgimdebt_page():
    return render_template('pgimdebt.html')

@app.route('/Portfolio.html')
def portfolio_page():
    return render_template('Portfolio.html')

@app.route('/signup.html')
def signup_page():
    return render_template('signup.html')

@app.route('/SIP.html')
def sip_page():
    return render_template('SIP.html')

@app.route('/transaction.html')
def transaction_page():
    return render_template('transaction.html')

@app.route('/transactionSell.html')
def transactionsell_page():
    return render_template('transactionSell.html')

@app.route('/transactionSip.html')
def transactionsip_page():
    return render_template('transactionSip.html')

# ================= AUTHENTICATION ROUTES =================

@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get('username')
    password = request.form.get('password')
    email = request.form.get('email')
    phone_number = request.form.get('phone_number')

    if not username or not password:
        return 'Missing required fields', 400

    try:
        # Check if user already exists
        existing_user = mongo.db.users.find_one({'username': username})
        if existing_user:
            return '''
                <script>
                    alert("User already exists");
                    window.location="/signup.html";
                </script>
            ''', 400

        # Hash password and create user
        hashed_password = generate_password_hash(password)
        
        mongo.db.users.insert_one({
            'username': username,
            'password': hashed_password,
            'email': email,
            'phone_number': phone_number,
            'createdAt': datetime.utcnow()
        })

        return redirect(url_for('login_page'))

    except Exception as e:
        print(f'Signup error: {e}')
        return 'Signup failed', 500

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    try:
        # Find user
        user = mongo.db.users.find_one({'username': username})
        if not user:
            return 'Invalid username or password', 401

        # Check password
        if not check_password_hash(user['password'], password):
            return 'Invalid username or password', 401

        return redirect(url_for('invester_page'))

    except Exception as e:
        print(f'Login error: {e}')
        return 'Login failed', 500

# ================= STOCK DATA API ROUTE =================

@app.route('/stock-data', methods=['POST'])
def stock_data():
    """Handle stock data requests from SIP.html form"""
    stock_name = request.form.get('stock')
    s = request.form.get('size')
    duration = request.form.get('timespan')
    fdate = request.form.get('fdate')
    tdate = request.form.get('tdate')
    boo = request.form.get('boolean')
    sor = request.form.get('sorting')
    limi = request.form.get('limit')
    appid = "mi1X4J_oOnXRX7YWMxiSAHDfTlnTRMMg"

    url = f"https://api.polygon.io/v2/aggs/ticker/{stock_name}/range/{s}/{duration}/{fdate}/{tdate}?adjusted={boo}&sort={sor}&limit={limi}&apiKey={appid}"

    try:
        response = requests.get(url)
        print(f"Status Code: {response.status_code}")

        if response.status_code == 200:
            data = response.json()
            
            if 'results' in data and len(data['results']) > 0:
                result = data['results'][0]
                
                v = result.get('v', 'N/A')
                vw = result.get('vw', 'N/A')
                c = result.get('c', 'N/A')
                h = result.get('h', 'N/A')
                o = result.get('o', 'N/A')
                l = result.get('l', 'N/A')
                t = result.get('t', 'N/A')
                n = result.get('n', 'N/A')

                html_response = f"""
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Stock Data - {stock_name}</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                    <style>
                        body {{
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            min-height: 100vh;
                            padding: 50px 0;
                        }}
                        .result-card {{
                            background: white;
                            border-radius: 15px;
                            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                            padding: 40px;
                            max-width: 800px;
                            margin: 0 auto;
                        }}
                        h2 {{
                            color: #667eea;
                            margin-bottom: 30px;
                        }}
                        .data-item {{
                            padding: 15px;
                            margin: 10px 0;
                            background: #f8f9fa;
                            border-left: 4px solid #667eea;
                            border-radius: 5px;
                        }}
                        .data-label {{
                            font-weight: bold;
                            color: #333;
                        }}
                        .data-value {{
                            color: #667eea;
                            font-size: 1.1em;
                        }}
                        .btn-back {{
                            margin-top: 30px;
                        }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="result-card">
                            <h2 class="text-center">📊 Stock Data for {stock_name}</h2>
                            
                            <div class="data-item">
                                <span class="data-label">Trading Volume:</span>
                                <span class="data-value">{v}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Volume Weighted Average Price:</span>
                                <span class="data-value">${vw}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Open Price:</span>
                                <span class="data-value">${o}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Close Price:</span>
                                <span class="data-value">${c}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Highest Price:</span>
                                <span class="data-value">${h}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Lowest Price:</span>
                                <span class="data-value">${l}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Unix Timestamp:</span>
                                <span class="data-value">{t}</span>
                            </div>
                            
                            <div class="data-item">
                                <span class="data-label">Number of Transactions:</span>
                                <span class="data-value">{n}</span>
                            </div>
                            
                            <div class="text-center">
                                <a href="/SIP.html" class="btn btn-primary btn-lg btn-back">🔙 Back to Search</a>
                            </div>
                        </div>
                    </div>
                </body>
                </html>
                """
                
                return html_response
            else:
                return """
                <!DOCTYPE html>
                <html>
                <head>
                    <title>No Data Found</title>
                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                </head>
                <body class="bg-light">
                    <div class="container mt-5">
                        <div class="alert alert-warning text-center">
                            <h3>⚠️ No data found for the given parameters</h3>
                            <p>Please check your input and try again.</p>
                            <a href="/SIP.html" class="btn btn-primary">Back to Search</a>
                        </div>
                    </div>
                </body>
                </html>
                """, 404
        else:
            return f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>API Error</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            </head>
            <body class="bg-light">
                <div class="container mt-5">
                    <div class="alert alert-danger text-center">
                        <h3>❌ API request failed</h3>
                        <p>Status code: {response.status_code}</p>
                        <a href="/SIP.html" class="btn btn-primary">Back to Search</a>
                    </div>
                </div>
            </body>
            </html>
            """, 500

    except Exception as e:
        print(f"Error: {e}")
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Error</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
            <div class="container mt-5">
                <div class="alert alert-danger text-center">
                    <h3>❌ An error occurred</h3>
                    <p>{str(e)}</p>
                    <a href="/SIP.html" class="btn btn-primary">Back to Search</a>
                </div>
            </div>
        </body>
        </html>
        """, 500

# ================= SERVER =================

if __name__ == '__main__':
    app.run(debug=True, port=3000)